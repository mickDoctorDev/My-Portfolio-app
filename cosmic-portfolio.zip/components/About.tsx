import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-32">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-300 to-pink-400">
          My Cosmic Journey
        </h2>
        <div className="max-w-3xl mx-auto bg-black/20 p-8 rounded-xl shadow-lg border border-purple-800/50">
          <p className="text-lg text-gray-300 leading-relaxed">
            Hello! I'm Mick, a passionate frontend developer charting my course through the digital cosmos. My journey began with a curiosity for how beautiful interfaces come to life, and it has since evolved into a full-blown mission to build seamless, user-centric web experiences.
          </p>
          <br />
          <p className="text-lg text-gray-300 leading-relaxed">
            With a strong command of modern web technologies, I love crafting responsive and dynamic applications. From the smallest component to the overall architecture, I am dedicated to writing clean, efficient, and scalable code. Let's build something amazing together and launch it into the web-iverse!
          </p>
        </div>
      </div>
    </section>
  );
};

export default About;
